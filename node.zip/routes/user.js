
/*
 * GET home page.
 */

exports.user = function(req, res){
  res.render('usr', { title: 'Express' })
};