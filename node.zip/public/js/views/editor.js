

$( document ).ready( function() {
	$( '#editor' ).ckeditor();
});
